﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telhai.cs.DotNet.TomerHarari.Infrastracture;

namespace Telhai.cs.DotNet.TomerHarari.Db
{
    public class SQLDb
    {
        public bool Connect(string url) {  return true; }

        public bool Execute(string expression) {  return false; }

        public void Close(){}

        public string GetData(string expression) {
            Logger.Log("1000");
            return "1000"; }
    }
}
