﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telhai.cs.DotNet.TomerHarari.Db;
using Telhai.cs.DotNet.TomerHarari.Infrastracture;

namespace Telhai.cs.DotNet.TomerHarari.App
{
    class Application
    {
        public static void Main(string[] args) {

            SQLDb sQLDb = new SQLDb();
            bool isConnected = sQLDb.Connect("123.133.11.199");
            if (!isConnected)
            {
                Logger.Log("failed to connect to the database");
            }
            isConnected = sQLDb.Execute("insert in to table values(1,2,3)");
            if (!isConnected) {
                Logger.Log("Error expretion");
            }
            sQLDb.Close();

        }
    }
}
