﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.cs.DotNet.TomerHarari.Infrastracture
{
    public class Logger
    {
        public static void Log(string message) { Console.WriteLine(message + ":" + DateTime.Now.ToString("o")); }

    }
}
