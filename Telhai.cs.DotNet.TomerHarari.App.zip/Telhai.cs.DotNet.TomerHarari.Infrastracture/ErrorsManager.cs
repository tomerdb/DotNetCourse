﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.cs.DotNet.TomerHarari.Infrastracture
{
    internal class ErrorsManager
    {
        public bool CheckValidExpression(string expression)
        {
            return true;
        }
    }
}
